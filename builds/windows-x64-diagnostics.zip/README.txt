Development diagnostics; NOT PLAYABLE.
Runtime built 2026-10-27. Hash-verified launcher/DLL pair.
Saved-slot selection and stage placement reach Butterfly initialization, then crash with C0000005.
No completed stage frame or gameplay verified. Source contains a later material-storage repair tested in a component fixture, not included in this binary.
Standalone probe unchanged; self-test last passed 2026-10-18.
No game images, extracted assets, saves, HD packs, compilers, raw logs or debug dumps are included.
