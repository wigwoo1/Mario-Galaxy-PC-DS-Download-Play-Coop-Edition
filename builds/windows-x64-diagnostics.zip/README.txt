Development diagnostics, not a playable game.

Double-click Run diagnostic self-tests.cmd for the standalone tests (no game data required).
The runtime/ pair is the exact 2026-10-16 hidden boot diagnostic. It requires separately supplied game data and currently crashes at Kinopio ColorChange stage placement.
No game image, extracted assets, texture pack, save or dump is included.
See the repository README, build manifest and third-party notices.
