Development diagnostics - not playable.

Existing 2026-10-27 12:13 -04:00 diagnostic launcher/DLL pair; hash-verified
against its runtime manifest. Publisher did not rebuild these binaries.
The original runtime reaches scene-ready but fails in Mario's normal draw
on an unregistered private display-list buffer. No complete stage frame or
controllable gameplay is verified. Components and model regression passed.
The runtime uses automated diagnostic input and a hidden window.
Run diagnostic self-tests.cmd checks the standalone probe only.
No game assets, saves, logs, dumps, PDBs or compiler downloads are included.