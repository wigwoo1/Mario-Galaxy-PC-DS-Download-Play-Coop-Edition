@echo off
cd /d "%~dp0"
galaxy-probe.exe --self-test
set "testResult=%errorlevel%"
if "%testResult%"=="0" (echo PASS: diagnostic self-tests.) else (echo FAIL: diagnostic self-tests. Exit %testResult%.)
echo This is a diagnostic, not playable gameplay.
pause
exit /b %testResult%
